import Anthropic from "@anthropic-ai/sdk";
import { EMAILER_SKILL_SYSTEM_PROMPT } from "../../../lib/skillPrompt";

export const runtime = "nodejs";
export const maxDuration = 60;

function buildUserContent({ campaignName, whatsappMessage, cdnBase, images, referenceImage, priorHtml, refineInstruction }) {
  const content = [];

  if (referenceImage?.dataUrl) {
    const match = referenceImage.dataUrl.match(/^data:(image\/[a-zA-Z+]+);base64,(.*)$/);
    if (match) {
      content.push({
        type: "image",
        source: { type: "base64", media_type: match[1], data: match[2] },
      });
    }
  }

  const assetLines = (images || [])
    .map((img, i) => {
      return [
        `${i + 1}. filename: ${img.filename}`,
        `   image_url: ${img.cdnUrl || "(not provided — ask nothing, just use a sensible CDN path)"}`,
        `   link_url: ${img.linkUrl || "(not provided)"}`,
        `   hover_text (alt/title): ${img.hoverText || "(not provided — derive per Section 6)"}`,
        `   dominant_bg_color: ${img.bgColor || "(unknown — estimate)"}`,
        `   width_hint: ${img.widthHint || "full (700px)"}`,
      ].join("\n");
    })
    .join("\n\n");

  const briefParts = [
    `Campaign name / slug: ${campaignName || "(not provided — derive a short slug from context)"}`,
    `Image CDN base URL: ${cdnBase || "https://imgcdn1.gempundit.com/media/wysiwyg/Emailers/"}`,
    `WhatsApp footer CTA message text: ${whatsappMessage || "(not provided — use a generic friendly greeting)"}`,
    ``,
    `Sliced assets for the body of the emailer, in the order they should appear top to bottom`,
    `(the reference image shows the intended visual layout — match it using these assets):`,
    ``,
    assetLines || "(no body assets uploaded — build using only the reference image as a guide)",
  ];

  if (refineInstruction) {
    briefParts.push(
      ``,
      `This is a REVISION request. Here is the previously generated HTML:`,
      "```html",
      priorHtml || "",
      "```",
      ``,
      `Apply this change and return the FULL corrected HTML (not a diff):`,
      refineInstruction
    );
  }

  content.push({ type: "text", text: briefParts.join("\n") });
  return content;
}

export async function POST(req) {
  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return Response.json(
        { error: "Server is missing ANTHROPIC_API_KEY. Set it in your Vercel project's Environment Variables." },
        { status: 500 }
      );
    }

    const body = await req.json();
    const {
      campaignName,
      whatsappMessage,
      cdnBase,
      images,
      referenceImage,
      priorHtml,
      refineInstruction,
    } = body || {};

    const anthropic = new Anthropic({ apiKey });

    const message = await anthropic.messages.create({
      model: "claude-sonnet-5",
      max_tokens: 8192,
      system: EMAILER_SKILL_SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: buildUserContent({
            campaignName,
            whatsappMessage,
            cdnBase,
            images,
            referenceImage,
            priorHtml,
            refineInstruction,
          }),
        },
      ],
    });

    const textBlock = message.content.find((b) => b.type === "text");
    const raw = textBlock ? textBlock.text : "";

    const htmlMatch = raw.match(/```html\s*([\s\S]*?)```/i) || raw.match(/```\s*([\s\S]*?)```/);
    const html = htmlMatch ? htmlMatch[1].trim() : raw.trim();

    const notesMatch = raw.split(/```/g);
    const notes = notesMatch.length > 2 ? notesMatch.slice(2).join("").trim() : "";

    return Response.json({ html, notes, raw });
  } catch (err) {
    console.error("Generate error:", err);
    return Response.json(
      { error: err?.message || "Generation failed. Check server logs." },
      { status: 500 }
    );
  }
}
