import "./globals.css";

export const metadata = {
  title: "GemPundit Emailer Builder",
  description: "Upload assets, edit hover text / links / images / WhatsApp CTA, and generate a send-ready GemPundit emailer.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
