"use client";

import { useState, useRef } from "react";
import styles from "./page.module.css";
import { extractImagesFromZip, estimateDominantColor } from "../lib/assets";

const DEFAULT_CDN_BASE = "https://imgcdn1.gempundit.com/media/wysiwyg/Emailers/";

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function Page() {
  const [campaignName, setCampaignName] = useState("");
  const [cdnBase, setCdnBase] = useState(DEFAULT_CDN_BASE);
  const [whatsappMessage, setWhatsappMessage] = useState("");
  const [referenceImage, setReferenceImage] = useState(null); // { dataUrl, name }
  const [images, setImages] = useState([]); // extracted + editable assets
  const [zipName, setZipName] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null); // { html, notes }
  const [activeTab, setActiveTab] = useState("preview");
  const [refineText, setRefineText] = useState("");
  const [refining, setRefining] = useState(false);

  const zipInputRef = useRef(null);
  const refInputRef = useRef(null);

  async function handleZipUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setZipName(file.name);
    setError("");
    try {
      const extracted = await extractImagesFromZip(file);
      const withDefaults = extracted.map((img, i) => ({
        id: `${Date.now()}_${i}`,
        filename: img.filename,
        dataUrl: img.dataUrl,
        cdnUrl: cdnBase + img.filename,
        linkUrl: "",
        hoverText: "",
        bgColor: "",
        widthHint: "full",
      }));
      setImages(withDefaults);

      // Estimate dominant colors in the background, per image.
      withDefaults.forEach(async (img, idx) => {
        const color = await estimateDominantColor(img.dataUrl);
        if (color) {
          setImages((prev) => {
            const next = [...prev];
            const at = next.findIndex((x) => x.id === img.id);
            if (at !== -1) next[at] = { ...next[at], bgColor: next[at].bgColor || color };
            return next;
          });
        }
      });
    } catch (err) {
      setError("Couldn't read that zip file. Make sure it contains .gif/.png/.jpg assets.");
    }
  }

  async function handleRefUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await fileToDataUrl(file);
    setReferenceImage({ dataUrl, name: file.name });
  }

  function updateImage(id, patch) {
    setImages((prev) => prev.map((img) => (img.id === id ? { ...img, ...patch } : img)));
  }

  function moveImage(id, dir) {
    setImages((prev) => {
      const idx = prev.findIndex((i) => i.id === id);
      const swapWith = idx + dir;
      if (swapWith < 0 || swapWith >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[swapWith]] = [next[swapWith], next[idx]];
      return next;
    });
  }

  function removeImage(id) {
    setImages((prev) => prev.filter((i) => i.id !== id));
  }

  function applyCdnBaseToAll() {
    setImages((prev) => prev.map((img) => ({ ...img, cdnUrl: cdnBase + img.filename })));
  }

  async function handleGenerate() {
    setLoading(true);
    setError("");
    setResult(null);
    setActiveTab("preview");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaignName,
          whatsappMessage,
          cdnBase,
          referenceImage,
          images: images.map(({ filename, cdnUrl, linkUrl, hoverText, bgColor, widthHint }) => ({
            filename, cdnUrl, linkUrl, hoverText, bgColor, widthHint,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Generation failed.");
      setResult({ html: data.html, notes: data.notes });
    } catch (err) {
      setError(err.message || "Something went wrong generating the emailer.");
    } finally {
      setLoading(false);
    }
  }

  async function handleRefine() {
    if (!refineText.trim() || !result) return;
    setRefining(true);
    setError("");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaignName,
          whatsappMessage,
          cdnBase,
          referenceImage,
          images: images.map(({ filename, cdnUrl, linkUrl, hoverText, bgColor, widthHint }) => ({
            filename, cdnUrl, linkUrl, hoverText, bgColor, widthHint,
          })),
          priorHtml: result.html,
          refineInstruction: refineText,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Revision failed.");
      setResult({ html: data.html, notes: data.notes });
      setRefineText("");
    } catch (err) {
      setError(err.message || "Something went wrong applying that revision.");
    } finally {
      setRefining(false);
    }
  }

  function copyHtml() {
    if (!result) return;
    navigator.clipboard.writeText(result.html);
  }

  function downloadHtml() {
    if (!result) return;
    const blob = new Blob([result.html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(campaignName || "gempundit-emailer").replace(/\s+/g, "-").toLowerCase()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className={styles.shell}>
      <header className={styles.topbar}>
        <div className={styles.brand}>
          <span className={styles.brandMark} />
          <div>
            <div className={styles.brandName}>GemPundit Emailer Builder</div>
            <div className={styles.brandSub}>assets → send-ready HTML</div>
          </div>
        </div>
        <span className={styles.skillTag}>/gempundit-emailer-builder-master-production-prompt</span>
      </header>

      <div className={styles.main}>
        <div className={styles.controls}>
          {/* 1. Campaign */}
          <section className={styles.section}>
            <div className={styles.sectionHead}>
              <span className={styles.sectionNum}>1</span>
              <span className={styles.sectionTitle}>Campaign</span>
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Campaign name / UTM slug</label>
              <input
                className={styles.input}
                placeholder="e.g. AugustWeekly1"
                value={campaignName}
                onChange={(e) => setCampaignName(e.target.value)}
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Image CDN base URL</label>
              <input
                className={styles.input}
                value={cdnBase}
                onChange={(e) => setCdnBase(e.target.value)}
                onBlur={applyCdnBaseToAll}
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>WhatsApp CTA message (footer wa.me text)</label>
              <textarea
                className={styles.textarea}
                placeholder="e.g. Hi, I'd like to know more about your gemstones"
                value={whatsappMessage}
                onChange={(e) => setWhatsappMessage(e.target.value)}
              />
            </div>
          </section>

          {/* 2. Reference image */}
          <section className={styles.section}>
            <div className={styles.sectionHead}>
              <span className={styles.sectionNum}>2</span>
              <span className={styles.sectionTitle}>Reference design</span>
            </div>
            <p className={styles.sectionHint}>The full campaign PNG. Claude matches layout, order, and colors from this.</p>
            <div className={`${styles.dropzone} ${referenceImage ? styles.hasFile : ""}`}>
              <span className={styles.dropzoneLabel}>
                {referenceImage ? referenceImage.name : "No reference image uploaded yet"}
              </span>
              <button className={styles.fileBtn} onClick={() => refInputRef.current?.click()}>
                {referenceImage ? "Replace PNG" : "Upload reference PNG"}
              </button>
              <input ref={refInputRef} type="file" accept="image/*" hidden onChange={handleRefUpload} />
            </div>
            {referenceImage && (
              <div className={styles.refPreview}>
                <img src={referenceImage.dataUrl} alt="Reference design" />
              </div>
            )}
          </section>

          {/* 3. Sliced assets */}
          <section className={styles.section}>
            <div className={styles.sectionHead}>
              <span className={styles.sectionNum}>3</span>
              <span className={styles.sectionTitle}>Sliced assets (.zip)</span>
            </div>
            <p className={styles.sectionHint}>
              Upload the designer's zip of sliced GIFs/PNGs. Edit hover text, link URL, image URL, and width per tile below — order matches top-to-bottom placement.
            </p>
            <div className={`${styles.dropzone} ${images.length ? styles.hasFile : ""}`}>
              <span className={styles.dropzoneLabel}>{zipName || "No assets zip uploaded yet"}</span>
              <button className={styles.fileBtn} onClick={() => zipInputRef.current?.click()}>
                {images.length ? "Replace zip" : "Upload assets zip"}
              </button>
              <input ref={zipInputRef} type="file" accept=".zip" hidden onChange={handleZipUpload} />
            </div>

            <div style={{ marginTop: 14 }}>
              {images.length === 0 && <div className={styles.emptyAssets}>Assets will appear here as editable tiles once uploaded.</div>}
              {images.map((img, idx) => (
                <div key={img.id} className={styles.assetCard}>
                  <div className={styles.assetTop}>
                    <img className={styles.assetThumb} src={img.dataUrl} alt={img.filename} />
                    <div className={styles.assetMeta}>
                      <div className={styles.assetFilename}>{img.filename}</div>
                      <div className={styles.widthToggle} style={{ marginTop: 6 }}>
                        <button
                          className={`${styles.widthBtn} ${img.widthHint === "full" ? styles.active : ""}`}
                          onClick={() => updateImage(img.id, { widthHint: "full" })}
                        >
                          700px full
                        </button>
                        <button
                          className={`${styles.widthBtn} ${img.widthHint === "half" ? styles.active : ""}`}
                          onClick={() => updateImage(img.id, { widthHint: "half" })}
                        >
                          350px half
                        </button>
                      </div>
                    </div>
                    <div className={styles.assetOrder}>
                      <button className={styles.orderBtn} onClick={() => moveImage(img.id, -1)} disabled={idx === 0} title="Move up">↑</button>
                      <button className={styles.orderBtn} onClick={() => moveImage(img.id, 1)} disabled={idx === images.length - 1} title="Move down">↓</button>
                      <button className={styles.orderBtn} onClick={() => removeImage(img.id)} title="Remove">✕</button>
                    </div>
                  </div>

                  <div className={styles.assetGrid}>
                    <div className={`${styles.field} ${styles.assetGridFull}`}>
                      <label className={styles.label}>Image URL (CDN)</label>
                      <input
                        className={styles.input}
                        value={img.cdnUrl}
                        onChange={(e) => updateImage(img.id, { cdnUrl: e.target.value })}
                      />
                    </div>
                    <div className={`${styles.field} ${styles.assetGridFull}`}>
                      <label className={styles.label}>Link URL</label>
                      <input
                        className={styles.input}
                        placeholder="https://www.gempundit.com/..."
                        value={img.linkUrl}
                        onChange={(e) => updateImage(img.id, { linkUrl: e.target.value })}
                      />
                    </div>
                    <div className={`${styles.field} ${styles.assetGridFull}`}>
                      <label className={styles.label}>Hover text (alt / title)</label>
                      <input
                        className={styles.input}
                        placeholder="e.g. White Sapphire Ring"
                        value={img.hoverText}
                        onChange={(e) => updateImage(img.id, { hoverText: e.target.value })}
                      />
                    </div>
                    <div className={styles.field}>
                      <label className={styles.label}>Background color</label>
                      <div className={styles.colorRow}>
                        <span className={styles.swatch} style={{ background: img.bgColor || "#0c0d11" }} />
                        <input
                          className={styles.input}
                          placeholder="#f9f1ee"
                          value={img.bgColor}
                          onChange={(e) => updateImage(img.id, { bgColor: e.target.value })}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <button className={styles.generateBtn} onClick={handleGenerate} disabled={loading}>
            {loading ? (<><span className={styles.spinner} />Building emailer…</>) : "Generate emailer HTML"}
          </button>
          {error && <div className={styles.errorBox}>{error}</div>}
        </div>

        <div className={styles.output}>
          {!result && !loading && (
            <div className={styles.outputEmpty}>
              <div>
                <span className="big" style={{ display: "block" }} />
                <span className={styles.big}>Nothing built yet</span>
                Fill in campaign details and assets on the left, then generate.
              </div>
            </div>
          )}

          {loading && (
            <div className={styles.outputEmpty}>
              <div><span className={styles.spinner} />Writing table-safe HTML from your assets…</div>
            </div>
          )}

          {result && !loading && (
            <>
              <div className={styles.tabs}>
                <button className={`${styles.tab} ${activeTab === "preview" ? styles.active : ""}`} onClick={() => setActiveTab("preview")}>Preview</button>
                <button className={`${styles.tab} ${activeTab === "code" ? styles.active : ""}`} onClick={() => setActiveTab("code")}>Code</button>
                <div className={styles.toolbar}>
                  <button className={styles.tinyBtn} onClick={copyHtml}>Copy HTML</button>
                  <button className={styles.tinyBtn} onClick={downloadHtml}>Download .html</button>
                </div>
              </div>

              {activeTab === "preview" ? (
                <div className={styles.previewFrameWrap}>
                  <iframe className={styles.previewFrame} srcDoc={result.html} title="Emailer preview" />
                </div>
              ) : (
                <div className={styles.codeBox}>
                  <pre>{result.html}</pre>
                </div>
              )}

              {result.notes && (
                <div className={styles.notes}><b>QA NOTES</b><br />{result.notes}</div>
              )}

              <div className={styles.refineRow}>
                <input
                  className={styles.input}
                  placeholder="Request a fix, e.g. 'make row 3 two columns' or 'fix the WhatsApp link'"
                  value={refineText}
                  onChange={(e) => setRefineText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleRefine()}
                />
                <button className={styles.refineBtn} onClick={handleRefine} disabled={refining || !refineText.trim()}>
                  {refining ? "Applying…" : "Apply fix"}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
